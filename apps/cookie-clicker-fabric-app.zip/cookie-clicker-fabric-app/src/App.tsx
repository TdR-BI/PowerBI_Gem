import React, { useState, useEffect, useCallback } from 'react';
import { INITIAL_BUILDINGS, INITIAL_UPGRADES, Building, Upgrade } from './gameData';
import './App.css';

interface FloatingNumber {
  id: number;
  x: number;
  y: number;
  value: string;
}

const SAVE_KEY = 'cookie_clicker_fabric_save_v1';

export function App() {
  const [cookies, setCookies] = useState<number>(0);
  const [totalBaked, setTotalBaked] = useState<number>(0);
  const [buildings, setBuildings] = useState<Building[]>(INITIAL_BUILDINGS);
  const [upgrades, setUpgrades] = useState<Upgrade[]>(INITIAL_UPGRADES);
  const [bakeryName, setBakeryName] = useState<string>('Fabric Bakkerij');
  const [floatingNumbers, setFloatingNumbers] = useState<FloatingNumber[]>([]);
  const [goldenCookie, setGoldenCookie] = useState<{ x: number; y: number } | null>(null);
  const [frenzyMultiplier, setFrenzyMultiplier] = useState<number>(1);
  const [newsTicker, setNewsTicker] = useState<string>('Welkom in je Fabric Koekjesfabriek! Klik op het koekje om te beginnen.');

  // Load saved game
  useEffect(() => {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (typeof parsed.cookies === 'number') setCookies(parsed.cookies);
        if (typeof parsed.totalBaked === 'number') setTotalBaked(parsed.totalBaked);
        if (Array.isArray(parsed.buildings)) setBuildings(parsed.buildings);
        if (Array.isArray(parsed.upgrades)) setUpgrades(parsed.upgrades);
        if (typeof parsed.bakeryName === 'string') setBakeryName(parsed.bakeryName);
      } catch (e) {
        console.error('Kon savegame niet laden:', e);
      }
    }
  }, []);

  // Calculate multipliers
  const getBuildingMultiplier = useCallback(
    (buildingId: string) => {
      return upgrades
        .filter((u) => u.purchased && u.targetBuildingId === buildingId)
        .reduce((acc, u) => acc * u.multiplier, 1);
    },
    [upgrades]
  );

  const clickMultiplier = upgrades
    .filter((u) => u.purchased && u.targetBuildingId === 'click')
    .reduce((acc, u) => acc * u.multiplier, 1);

  const cookiesPerClick = 1 * clickMultiplier * frenzyMultiplier;

  const cookiesPerSecond =
    buildings.reduce((sum, b) => {
      return sum + b.count * b.cps * getBuildingMultiplier(b.id);
    }, 0) * frenzyMultiplier;

  // Game loop (10 ticks per second)
  useEffect(() => {
    const interval = setInterval(() => {
      if (cookiesPerSecond > 0) {
        const delta = cookiesPerSecond / 10;
        setCookies((prev) => prev + delta);
        setTotalBaked((prev) => prev + delta);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [cookiesPerSecond]);

  // Auto-save every 10 seconds
  useEffect(() => {
    const saveTimer = setInterval(() => {
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({ cookies, totalBaked, buildings, upgrades, bakeryName })
      );
    }, 10000);
    return () => clearInterval(saveTimer);
  }, [cookies, totalBaked, buildings, upgrades, bakeryName]);

  // Golden Cookie spawner
  useEffect(() => {
    const spawner = setInterval(() => {
      if (!goldenCookie && Math.random() < 0.35) {
        setGoldenCookie({
          x: 15 + Math.random() * 65,
          y: 20 + Math.random() * 60
        });
        setTimeout(() => setGoldenCookie(null), 12000);
      }
    }, 20000);
    return () => clearInterval(spawner);
  }, [goldenCookie]);

  // News ticker updates
  useEffect(() => {
    const headlines = [
      'Nieuws: Microsoft Fabric gebruikers bakken recordaantal koekjes in de cloud.',
      'Nieuws: Lokale oma’s eisen betere deegrollers en extra chocolade.',
      'Nieuws: Wetenschappers ontdekken dat koekjesdeeg uit goede data bestaat.',
      'Tip: Klik op Gouden Koekjes voor een tijdelijke 7x productie-boost!'
    ];
    const timer = setInterval(() => {
      setNewsTicker(headlines[Math.floor(Math.random() * headlines.length)]);
    }, 9000);
    return () => clearInterval(timer);
  }, []);

  const handleCookieClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    setCookies((prev) => prev + cookiesPerClick);
    setTotalBaked((prev) => prev + cookiesPerClick);

    const rect = e.currentTarget.getBoundingClientRect();
    const id = Date.now() + Math.random();
    const newFloat: FloatingNumber = {
      id,
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      value: `+${formatNumber(cookiesPerClick)}`
    };
    setFloatingNumbers((prev) => [...prev.slice(-15), newFloat]);
    setTimeout(() => {
      setFloatingNumbers((prev) => prev.filter((item) => item.id !== id));
    }, 900);
  };

  const getBuildingCost = (b: Building) => Math.floor(b.baseCost * Math.pow(1.15, b.count));

  const buyBuilding = (id: string) => {
    setBuildings((prev) =>
      prev.map((b) => {
        if (b.id !== id) return b;
        const cost = getBuildingCost(b);
        if (cookies < cost) return b;
        setCookies((c) => c - cost);
        return { ...b, count: b.count + 1 };
      })
    );
  };

  const buyUpgrade = (id: string) => {
    const target = upgrades.find((u) => u.id === id);
    if (!target || target.purchased || cookies < target.cost) return;
    setCookies((c) => c - target.cost);
    setUpgrades((prev) => prev.map((u) => (u.id === id ? { ...u, purchased: true } : u)));
  };

  const claimGoldenCookie = () => {
    setGoldenCookie(null);
    setFrenzyMultiplier(7);
    setNewsTicker('GOUDEN KOEKJE! 7x Koekjesproductie voor 20 seconden!');
    setTimeout(() => {
      setFrenzyMultiplier(1);
    }, 20000);
  };

  const resetGame = () => {
    if (window.confirm('Weet je zeker dat je je voortgang wilt wissen?')) {
      localStorage.removeItem(SAVE_KEY);
      setCookies(0);
      setTotalBaked(0);
      setBuildings(INITIAL_BUILDINGS);
      setUpgrades(INITIAL_UPGRADES);
    }
  };

  return (
    <div className="game-layout">
      {/* Left Panel: Big Cookie */}
      <section className="left-panel">
        <div className="bakery-header">
          <input
            className="bakery-title"
            value={bakeryName}
            onChange={(e) => setBakeryName(e.target.value)}
            aria-label="Bakkerij naam"
          />
          <div className="cookie-counter">{formatNumber(Math.floor(cookies))} koekjes</div>
          <div className="cps-counter">
            per seconde: <strong>{formatNumber(cookiesPerSecond)}</strong>
            {frenzyMultiplier > 1 && <span className="frenzy-badge"> ({frenzyMultiplier}x FRENZY!)</span>}
          </div>
        </div>

        <div className="cookie-stage">
          <button className="big-cookie" onClick={handleCookieClick} aria-label="Klik op het koekje">
            🍪
          </button>
          {floatingNumbers.map((f) => (
            <span key={f.id} className="floating-plus" style={{ left: f.x, top: f.y }}>
              {f.value}
            </span>
          ))}
        </div>

        <div className="footer-controls">
          <span>Totaal gebakken: {formatNumber(Math.floor(totalBaked))}</span>
          <button className="reset-btn" onClick={resetGame}>
            Reset Save
          </button>
        </div>
      </section>

      {/* Center Panel: Stats & News */}
      <section className="center-panel">
        <div className="news-banner">📰 {newsTicker}</div>
        <div className="buildings-showcase">
          <h2>Jouw Productielijn</h2>
          {buildings.filter((b) => b.count > 0).length === 0 ? (
            <p className="empty-hint">Koop rechts je eerste Cursor of Oma om je fabriek te vullen!</p>
          ) : (
            <div className="showcase-list">
              {buildings
                .filter((b) => b.count > 0)
                .map((b) => (
                  <div key={b.id} className="showcase-row">
                    <span className="showcase-label">
                      {b.icon} {b.name} ({b.count})
                    </span>
                    <span className="showcase-icons">
                      {Array.from({ length: Math.min(b.count, 24) }).map((_, i) => (
                        <span key={i}>{b.icon}</span>
                      ))}
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>
      </section>

      {/* Right Panel: Store (Upgrades & Buildings) */}
      <aside className="right-panel">
        <h2>Winkel</h2>

        <div className="store-section">
          <h3>Upgrades</h3>
          <div className="upgrades-grid">
            {upgrades
              .filter((u) => !u.purchased)
              .map((u) => {
                const canAfford = cookies >= u.cost;
                return (
                  <button
                    key={u.id}
                    className={`upgrade-tile ${canAfford ? 'affordable' : 'locked'}`}
                    onClick={() => buyUpgrade(u.id)}
                    title={`${u.name} (${formatNumber(u.cost)} koekjes): ${u.description}`}
                  >
                    <span className="upgrade-icon">{u.icon}</span>
                    <span className="upgrade-cost">{formatNumber(u.cost)}</span>
                  </button>
                );
              })}
          </div>
        </div>

        <div className="store-section">
          <h3>Gebouwen</h3>
          <div className="buildings-list">
            {buildings.map((b) => {
              const cost = getBuildingCost(b);
              const canAfford = cookies >= cost;
              return (
                <button
                  key={b.id}
                  className={`building-card ${canAfford ? 'affordable' : 'locked'}`}
                  onClick={() => buyBuilding(b.id)}
                >
                  <div className="building-icon">{b.icon}</div>
                  <div className="building-info">
                    <div className="building-name">{b.name}</div>
                    <div className="building-cost">🍪 {formatNumber(cost)}</div>
                    <div className="building-desc">+{formatNumber(b.cps * getBuildingMultiplier(b.id))} / sec</div>
                  </div>
                  <div className="building-count">{b.count}</div>
                </button>
              );
            })}
          </div>
        </div>
      </aside>

      {goldenCookie && (
        <button
          className="golden-cookie"
          style={{ left: `${goldenCookie.x}%`, top: `${goldenCookie.y}%` }}
          onClick={claimGoldenCookie}
          title="Klik voor 7x Frenzy!"
        >
          🌟🍪
        </button>
      )}
    </div>
  );
}

function formatNumber(num: number): string {
  if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(2) + ' mld';
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(2) + ' mln';
  if (num >= 10_000) return Math.floor(num).toLocaleString('nl-NL');
  return Number.isInteger(num) ? num.toString() : num.toFixed(1);
}

export default App;
