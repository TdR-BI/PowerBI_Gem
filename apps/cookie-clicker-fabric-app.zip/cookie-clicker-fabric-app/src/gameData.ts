export interface Building {
  id: string;
  name: string;
  icon: string;
  baseCost: number;
  cps: number;
  count: number;
  description: string;
}

export interface Upgrade {
  id: string;
  name: string;
  cost: number;
  icon: string;
  description: string;
  targetBuildingId: string | 'click';
  multiplier: number;
  purchased: boolean;
  unlockRequirement: number;
}

export const INITIAL_BUILDINGS: Building[] = [
  { id: 'cursor', name: 'Cursor', icon: '👆', baseCost: 15, cps: 0.1, count: 0, description: 'Klikt automatisch elke 10 seconden.' },
  { id: 'grandma', name: 'Oma', icon: '👵', baseCost: 100, cps: 1, count: 0, description: 'Een lieve oma die verse koekjes bakt.' },
  { id: 'farm', name: 'Boerderij', icon: '🌾', baseCost: 1100, cps: 8, count: 0, description: 'Kweekt koekjesplanten uit koekjeszaad.' },
  { id: 'mine', name: 'Mijn', icon: '⛏️', baseCost: 12000, cps: 47, count: 0, description: 'Delft diep naar chocoladedruppels en koekjesdeeg.' },
  { id: 'factory', name: 'Fabriek', icon: '🏭', baseCost: 130000, cps: 260, count: 0, description: 'Produceert enorme hoeveelheden koekjes aan de lopende band.' },
  { id: 'bank', name: 'Bank', icon: '🏦', baseCost: 1400000, cps: 1400, count: 0, description: 'Genereert koekjes uit rente op je koekjesvoorraad.' },
  { id: 'temple', name: 'Tempel', icon: '🏛️', baseCost: 20000000, cps: 7800, count: 0, description: 'Vol met kostbare, eeuwenoude chocolade.' },
  { id: 'wizard', name: 'Tovenaarstoren', icon: '🧙', baseCost: 330000000, cps: 44000, count: 0, description: 'Tovert koekjes tevoorschijn met spreuken.' }
];

export const INITIAL_UPGRADES: Upgrade[] = [
  { id: 'click-1', name: 'Versterkte Wijsvinger', cost: 100, icon: '⚡', description: 'Klikken en cursors zijn 2x zo efficiënt.', targetBuildingId: 'click', multiplier: 2, purchased: false, unlockRequirement: 1 },
  { id: 'cursor-1', name: 'Carpale Tunnel Crème', cost: 500, icon: '🧴', description: 'Cursors zijn 2x zo efficiënt.', targetBuildingId: 'cursor', multiplier: 2, purchased: false, unlockRequirement: 5 },
  { id: 'grandma-1', name: 'Deegrollers van Staal', cost: 1000, icon: '🥖', description: "Oma's bakken 2x zo snel.", targetBuildingId: 'grandma', multiplier: 2, purchased: false, unlockRequirement: 1 },
  { id: 'farm-1', name: 'Goedkope Kunstmest', cost: 11000, icon: '🌱', description: 'Boerderijen produceren 2x zoveel.', targetBuildingId: 'farm', multiplier: 2, purchased: false, unlockRequirement: 1 },
  { id: 'mine-1', name: 'Suikergas', cost: 120000, icon: '💎', description: 'Mijnen zijn 2x zo efficiënt.', targetBuildingId: 'mine', multiplier: 2, purchased: false, unlockRequirement: 1 },
  { id: 'factory-1', name: 'Stabiele Lopende Banden', cost: 1300000, icon: '⚙️', description: 'Fabrieken werken 2x zo snel.', targetBuildingId: 'factory', multiplier: 2, purchased: false, unlockRequirement: 1 }
];
