# Cookie Clicker – Fabric App

Een volledige kloon van Cookie Clicker (geïnspireerd op Orteil's Cookie Clicker) gebouwd met **React + TypeScript + Vite**, klaargemaakt om in **GitHub** te zetten en vanuit daar te koppelen/pullen naar **Microsoft Fabric** (of een andere Fabric-omgeving).

## Mappenstructuur

```text
cookie-clicker-fabric-app/
├── manifest/
│   └── workload-manifest.json   # Configuratie voor Microsoft Fabric Workload / Extensibility
├── src/
│   ├── App.tsx                  # Hoofdcomponent (game loop, golden cookies, winkel, savegame)
│   ├── App.css                  # Styling (3-koloms lay-out zoals het origineel)
│   ├── gameData.ts              # Gebouwen, upgrades en balanswaarden
│   └── main.tsx                 # React entry point
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## Stappen om naar GitHub te pushen en in Fabric te pullen

### 1. Zet deze map op GitHub
Open een terminal in de uitgepakte map `cookie-clicker-fabric-app` en voer uit:
```bash
git init
git add .
git commit -m "Initial commit: Cookie Clicker Fabric App"
git branch -M main
git remote add origin https://github.com/<JOUW-GEBRUIKERSNAAM>/cookie-clicker-fabric-app.git
git push -u origin main
```

### 2. Pullen in Microsoft Fabric
Afhankelijk van hoe je Fabric gebruikt:
- **Microsoft Fabric Workload / Extensibility Toolkit (Custom Fabric App):**
  1. Koppel je GitHub-repository in je Fabric Dev-omgeving of clone de repo lokaal in de Fabric Workload Dev Gateway (`npm install && npm run dev` draait standaard op poort `60006`, zoals geconfigureerd in `vite.config.ts` en `manifest/workload-manifest.json`).
  2. Registreer het manifest uit `manifest/workload-manifest.json` in je Fabric Admin Portal / Dev Mode om de app direct binnen Microsoft Fabric te openen.
- **Microsoft Fabric Workspace Git Integration:**
  1. Ga in Microsoft Fabric naar je **Workspace** > **Workspace settings** > **Git integration**.
  2. Kies **GitHub**, koppel je account en selecteer de repository `cookie-clicker-fabric-app` (branch `main`).
  3. Klik op **Connect and sync** om de bestanden vanuit GitHub naar Fabric te pullen.
